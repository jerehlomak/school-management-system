
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI;

// Middleware
app.use(cors());
app.use(express.json()); // For parsing application/json

// Import models for initial data population
const User = require('./models/User');
const Course = require('./models/Course');
const StudentTermGrade = require('./models/StudentTermGrade');
const Payment = require('./models/Payment');
const SchoolClass = require('./models/SchoolClass');
const ClassLevel = require('./models/ClassLevel');

// --- Initial Data ---
const { MOCK_USERS, MOCK_COURSES, MOCK_PAYMENTS, MOCK_STUDENT_TERM_GRADES, MOCK_CLASSES, MOCK_CLASS_LEVELS } = require('../constants'); // Get initial data from constants

// Function to populate initial data
const populateInitialData = async () => {
  try {
    // Populate ClassLevels first
    const classLevelCount = await ClassLevel.countDocuments();
    if (classLevelCount === 0) {
      await ClassLevel.insertMany(MOCK_CLASS_LEVELS);
      console.log('ClassLevels populated.');
    }

    // Populate SchoolClasses
    const classCount = await SchoolClass.countDocuments();
    if (classCount === 0) {
      await SchoolClass.insertMany(MOCK_CLASSES);
      console.log('SchoolClasses populated.');
    }

    // Populate Users
    const userCount = await User.countDocuments();
    if (userCount === 0) {
      await User.insertMany(MOCK_USERS);
      console.log('Users populated.');
    }

    // Populate Courses
    const courseCount = await Course.countDocuments();
    if (courseCount === 0) {
      await Course.insertMany(MOCK_COURSES);
      console.log('Courses populated.');
    }

    // Populate StudentTermGrades
    const gradeCount = await StudentTermGrade.countDocuments();
    if (gradeCount === 0) {
      await StudentTermGrade.insertMany(MOCK_STUDENT_TERM_GRADES);
      console.log('StudentTermGrades populated.');
    }

    // Populate Payments
    const paymentCount = await Payment.countDocuments();
    if (paymentCount === 0) {
      await Payment.insertMany(MOCK_PAYMENTS);
      console.log('Payments populated.');
    }
    
  } catch (error) {
    console.error('Error populating initial data:', error);
  }
};
// --- End Initial Data ---

// MongoDB Connection
mongoose.connect(MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
    populateInitialData(); // Populate data on successful connection
  })
  .catch(err => {
    console.error('MongoDB connection error:', err);
  });

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/courses', require('./routes/courses'));
app.use('/api/grades', require('./routes/grades'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/classes', require('./routes/classes'));
app.use('/api/class-levels', require('./routes/classLevels'));

// Basic route for testing server
app.get('/', (req, res) => {
  res.send('Edves Portal Backend API is running!');
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
