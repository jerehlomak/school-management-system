
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Course = require('../models/Course'); // Needed for updating course students/teachers
const ClassLevel = require('../models/ClassLevel'); // Needed for student ID generation
const SchoolClass = require('../models/SchoolClass'); // Needed for student ID generation
const { generateUniqueAlphaNumericId, generateRandomPassword, generateStudentId } = require('../../constants'); // Reuse frontend utilities

// Helper to calculate next student number without relying on localStorage
const getNextStudentNumberFromDB = async (classLevelType) => {
    const lastStudent = await User.findOne({ role: 'student', id: new RegExp(`^${classLevelType}/`) })
                                  .sort({ id: -1 }); // Sort by ID descending to get the last one
    
    let nextNum = 1;
    if (lastStudent && lastStudent.id) {
        const parts = lastStudent.id.split('/');
        const lastNum = parseInt(parts[1], 10);
        if (!isNaN(lastNum)) {
            nextNum = lastNum + 1;
        }
    }
    return nextNum;
};

// Helper to generate student ID on backend
const generateBackendStudentId = async (classLevelId) => {
    const classLevel = await ClassLevel.findOne({ id: classLevelId });
    if (!classLevel) {
        throw new Error(`Class level with ID ${classLevelId} not found.`);
    }
    const classLevelType = classLevel.type; // 'JSS' or 'SSS'

    const studentNum = await getNextStudentNumberFromDB(classLevelType);
    const formattedNum = String(studentNum).padStart(3, '0');
    const CURRENT_ACADEMIC_YEAR = new Date().getFullYear();
    return `${classLevelType}/${formattedNum}/${CURRENT_ACADEMIC_YEAR}`;
};


// GET /api/users - Fetch all users (with optional password stripping)
router.get('/', async (req, res) => {
  const includePasswords = req.query.includePasswords === 'true'; // Admin-only flag
  try {
    let users = await User.find({});
    if (!includePasswords) {
      users = users.map(user => {
        const userObj = user.toObject();
        delete userObj.password;
        return userObj;
      });
    }
    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Server error fetching users' });
  }
});

// GET /api/users/students-without-parents
router.get('/students-without-parents', async (req, res) => {
  try {
    const students = await User.find({ role: 'student', parentId: null });
    res.json(students);
  } catch (error) {
    console.error('Error fetching students without parents:', error);
    res.status(500).json({ message: 'Server error fetching students without parents' });
  }
});

// PUT /api/users/:id - Update a user
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  try {
    const user = await User.findOneAndUpdate({ id }, updates, { new: true });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    const userResponse = user.toObject();
    delete userResponse.password; // Don't send password back
    res.json(userResponse);
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ message: 'Server error updating user' });
  }
});

// POST /api/users/register-student
router.post('/register-student', async (req, res) => {
  const { studentName, email, classId, subjectsEnrolled, admissionYear, parentId } = req.body;

  try {
    const existingUsername = await User.findOne({ username: `student_${classId}_${generateUniqueAlphaNumericId('', [])}` }); // Placeholder check
    if (existingUsername) {
      return res.status(400).json({ message: 'Generated username already exists. Please try again.' });
    }

    const parentUser = await User.findOne({ id: parentId, role: 'parent' });
    if (!parentUser || !parentUser.phoneNumber) {
      return res.status(400).json({ message: 'Parent not found or parent does not have a phone number for student password.' });
    }

    const classObj = await SchoolClass.findOne({ id: classId });
    if (!classObj) {
        return res.status(400).json({ message: 'Invalid class selected.' });
    }

    const studentId = await generateBackendStudentId(classObj.classLevelId);
    const username = `student_${studentId.replace(/\//g, '_')}`;
    const password = parentUser.phoneNumber; // Student password is parent's phone number

    const newStudent = new User({
      id: studentId,
      username,
      password,
      name: studentName,
      email,
      phoneNumber: parentUser.phoneNumber, // Student phone is parent's phone
      role: 'student',
      classId,
      subjectsEnrolled,
      admissionYear,
      parentId,
    });

    await newStudent.save();

    // Update parent's studentIds array
    parentUser.studentIds.push(newStudent.id);
    await parentUser.save();

    // Update Courses to include the new student in enrolled courses
    await Course.updateMany(
      { id: { $in: subjectsEnrolled } },
      { $addToSet: { students: newStudent.id } } // Add student to courses without duplicates
    );

    const studentResponse = newStudent.toObject();
    delete studentResponse.password;
    res.status(201).json({ user: studentResponse, password: password });

  } catch (error) {
    console.error('Student registration failed:', error);
    res.status(500).json({ message: 'Server error during student registration', error: error.message });
  }
});

// POST /api/users/register-teacher
router.post('/register-teacher', async (req, res) => {
  const { teacherName, email, subjectsTaught, classLevelsTaught, phoneNumber } = req.body;

  try {
    const existingUser = await User.findOne({ $or: [{ email }, { phoneNumber }] });
    if (existingUser) {
        return res.status(400).json({ message: 'Email or phone number already registered.' });
    }

    const existingTeacherIds = await User.find({ role: 'teacher' }).select('id');
    const newTeacherId = generateUniqueAlphaNumericId('t', existingTeacherIds.map(u => u.id));
    const username = `teacher_${newTeacherId}`;
    const password = generateRandomPassword();

    const newTeacher = new User({
      id: newTeacherId,
      username,
      password,
      name: teacherName,
      email,
      phoneNumber,
      role: 'teacher',
      subjectsTaught,
      classLevelsTaught,
    });

    await newTeacher.save();

    // Update Courses to assign this teacher to the subjects they teach
    // Importantly, this will overwrite any previous teacher for these courses
    await Course.updateMany(
      { id: { $in: subjectsTaught } },
      { $set: { teacherId: newTeacher.id } }
    );
    
    const teacherResponse = newTeacher.toObject();
    delete teacherResponse.password;
    res.status(201).json({ user: teacherResponse, password });

  } catch (error) {
    console.error('Teacher registration failed:', error);
    res.status(500).json({ message: 'Server error during teacher registration', error: error.message });
  }
});

// POST /api/users/register-parent
router.post('/register-parent', async (req, res) => {
  const { parentName, email, phoneNumber, studentIdsToLink } = req.body;

  try {
    const existingUser = await User.findOne({ $or: [{ email }, { phoneNumber }] });
    if (existingUser) {
        return res.status(400).json({ message: 'Email or phone number already registered.' });
    }

    const existingParentIds = await User.find({ role: 'parent' }).select('id');
    const newParentId = generateUniqueAlphaNumericId('p', existingParentIds.map(u => u.id));
    const username = `parent_${newParentId}`;
    const password = generateRandomPassword(); // Parents get a random password

    const newParent = new User({
      id: newParentId,
      username,
      password,
      name: parentName,
      email,
      phoneNumber,
      role: 'parent',
      studentIds: studentIdsToLink || [],
    });

    await newParent.save();

    // Link students to this parent
    if (studentIdsToLink && studentIdsToLink.length > 0) {
      await User.updateMany(
        { id: { $in: studentIdsToLink }, role: 'student' },
        { $set: { parentId: newParent.id, password: newParent.phoneNumber, phoneNumber: newParent.phoneNumber } } // Set student password and phone number to parent's
      );
    }

    const parentResponse = newParent.toObject();
    delete parentResponse.password;
    res.status(201).json({ user: parentResponse, password });

  } catch (error) {
    console.error('Parent registration failed:', error);
    res.status(500).json({ message: 'Server error during parent registration', error: error.message });
  }
});


module.exports = router;
