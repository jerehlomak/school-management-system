
const express = require('express');
const router = express.Router();
const User = require('../models/User');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { identifier, password } = req.body;

  try {
    const user = await User.findOne({
      $or: [
        { username: identifier },
        { id: identifier },
        { phoneNumber: identifier, role: { $ne: 'student' } } // Teachers/Parents can use phone number
      ],
      password: password // In a real app, this would be hashed password comparison
    });

    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // In a real app, you'd generate a JWT token here
    const userResponse = user.toObject();
    delete userResponse.password; // Remove password from response

    res.json(userResponse);
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error during login' });
  }
});

module.exports = router;
