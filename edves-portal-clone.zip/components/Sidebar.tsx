
import React from 'react';
import { Link } from 'react-router-dom';
import { User, UserRole } from '../types';

interface SidebarProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ user, isOpen, onClose }) => {
  const getNavLinks = (role: UserRole) => {
    const commonLinks = [
      { path: '/', label: 'Dashboard' },
      { path: '/fees', label: 'Fees & Payments' },
    ];

    switch (role) {
      case UserRole.Student:
        return [
          ...commonLinks,
          { path: '/student/grades', label: 'My Grades' },
          { path: '/student/courses', label: 'My Courses' },
        ];
      case UserRole.Teacher:
        return [
          ...commonLinks,
          { path: '/teacher/classes', label: 'My Classes' },
          { path: '/teacher/grades', label: 'Enter Grades' },
        ];
      case UserRole.Parent:
        return [
          ...commonLinks,
          { path: '/parent/children', label: 'My Children' },
          { path: '/parent/payments', label: 'Payment History' },
        ];
      case UserRole.Admin:
        return [
          ...commonLinks,
          { path: '/admin/users', label: 'Manage Users' },
          { path: '/admin/manage-classes', label: 'Manage Classes' }, // New link for admin
          { path: '/admin/reports', label: 'Reports' },
        ];
      default:
        return [];
    }
  };

  const navLinks = getNavLinks(user.role);

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-gray-900 bg-opacity-75 z-30 md:hidden"
          onClick={onClose}
        ></div>
      )}

      <aside
        className={`fixed inset-y-0 left-0 w-64 bg-gray-800 text-white p-4 shadow-lg z-40
          transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0
          transition-transform duration-300 ease-in-out md:relative md:h-auto md:w-64`}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-blue-300">Navigation</h2>
          <button
            onClick={onClose}
            className="md:hidden text-white hover:text-gray-300 focus:outline-none"
            aria-label="Close sidebar"
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <nav>
          <ul>
            {navLinks.map((link) => (
              <li key={link.path} className="mb-2">
                <Link
                  to={link.path}
                  onClick={onClose}
                  className="block px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
