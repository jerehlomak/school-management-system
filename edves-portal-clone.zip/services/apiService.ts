
import { User, Course, StudentTermGrade, Payment, RRRInfo, PaymentStatus, UserRole, SchoolClass, ClassLevel } from '../types';
import { generateUniqueAlphaNumericId, generateRandomPassword, generateStudentId } from '../constants'; // Keep utilities

const BASE_URL = 'http://localhost:5000/api'; // Your backend API base URL

// Helper for API calls
const apiCall = async (endpoint: string, method: string, data?: any) => {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  const config: RequestInit = {
    method,
    headers,
  };

  if (data) {
    config.body = JSON.stringify(data);
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, config);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
    throw new Error(errorData.message || `API error: ${response.status}`);
  }

  if (response.status === 204) { // No Content
    return null;
  }

  return response.json();
};

/**
 * Simulates fetching user data from a backend.
 * Allows login using username, student ID, or phone number (for teachers/parents).
 */
export const fetchUser = async (identifier: string, password: string): Promise<User | null> => {
  try {
    const user = await apiCall('/auth/login', 'POST', { identifier, password });
    return user;
  } catch (error) {
    console.error('Login API error:', error);
    throw error; // Re-throw to be handled by the UI
  }
};

/**
 * Simulates fetching courses.
 */
export const fetchCourses = async (): Promise<Course[]> => {
  return apiCall('/courses', 'GET');
};

/**
 * Simulates fetching available segmented classes (e.g., JSS1A).
 */
export const fetchClasses = async (): Promise<SchoolClass[]> => {
  return apiCall('/classes', 'GET');
};

/**
 * Simulates fetching available class levels (e.g., JSS1).
 */
export const fetchClassLevels = async (): Promise<ClassLevel[]> => {
  return apiCall('/class-levels', 'GET');
};

/**
 * Simulates fetching detailed term grades for a specific student.
 */
export const fetchStudentTermGrades = async (studentId: string, courseId?: string, term?: number, year?: number): Promise<StudentTermGrade[]> => {
  const queryParams = new URLSearchParams();
  if (courseId) queryParams.append('courseId', courseId);
  if (term) queryParams.append('term', term.toString());
  if (year) queryParams.append('year', year.toString());

  return apiCall(`/grades/student/${studentId}?${queryParams.toString()}`, 'GET');
};

/**
 * Simulates fetching all term grades for courses taught by a teacher.
 */
export const fetchTeacherTermGrades = async (teacherId: string, courseId?: string, term?: number, year?: number): Promise<StudentTermGrade[]> => {
  const queryParams = new URLSearchParams();
  if (courseId) queryParams.append('courseId', courseId);
  if (term) queryParams.append('term', term.toString());
  if (year) queryParams.append('year', year.toString());

  return apiCall(`/grades/teacher/${teacherId}?${queryParams.toString()}`, 'GET');
};

/**
 * Simulates saving or updating a student's term grades.
 */
export const saveStudentTermGrade = async (grade: StudentTermGrade): Promise<StudentTermGrade> => {
  // The backend will handle creating a new ID or updating an existing one.
  return apiCall('/grades/save', 'POST', grade);
};


/**
 * Simulates calculating positions for students in a course for a specific term.
 * This now triggers a backend calculation.
 */
export const calculateCoursePositions = async (courseId: string, term: 1 | 2 | 3, year: number): Promise<StudentTermGrade[]> => {
  return apiCall('/grades/calculate-positions', 'POST', { courseId, term, year });
};

/**
 * Simulates fetching payments for a specific student.
 */
export const fetchStudentPayments = async (studentId: string): Promise<Payment[]> => {
  return apiCall(`/payments/student/${studentId}`, 'GET');
};

/**
 * Simulates generating a Remita RRR. This now calls the backend.
 */
export const generateRemitaRRR = async (studentId: string, amount: number, description: string): Promise<RRRInfo> => {
  return apiCall('/payments/generate-rrr', 'POST', { studentId, amount, description });
};

/**
 * Simulates updating a payment status.
 */
export const updatePaymentStatus = async (paymentId: string, status: PaymentStatus, rrr?: string): Promise<Payment | null> => {
  return apiCall(`/payments/${paymentId}/status`, 'PUT', { status, rrr });
};

/**
 * Simulates adding a new payment record.
 */
export const addPayment = async (newPayment: Omit<Payment, 'id'>): Promise<Payment> => {
  return apiCall('/payments/add', 'POST', newPayment);
};

/**
 * Simulates fetching all users (for admin). Passwords are only exposed if `includePasswords` is true.
 */
export const fetchAllUsers = async (includePasswords: boolean = false): Promise<User[]> => {
  return apiCall(`/users?includePasswords=${includePasswords}`, 'GET');
};

/**
 * Helper function to update a single user in the mock array and persist.
 * Now makes a backend API call.
 */
export const updateUser = async (updatedUser: User): Promise<User> => {
  return apiCall(`/users/${updatedUser.id}`, 'PUT', updatedUser);
};

/**
 * Simulates fetching all students who do not have a parentId.
 */
export const fetchStudentsWithoutParents = async (): Promise<User[]> => {
  return apiCall('/users/students-without-parents', 'GET');
};

/**
 * Simulates registering a new student.
 */
export const registerStudent = async (
  studentName: string,
  email: string,
  classId: string,
  subjectsEnrolled: string[],
  admissionYear: number,
  parentId: string,
): Promise<{ user: User; password: string }> => {
  // The backend will handle student ID generation, password setting (from parent's phone),
  // and linking the student's phone number.
  return apiCall('/users/register-student', 'POST', {
    studentName,
    email,
    classId,
    subjectsEnrolled,
    admissionYear,
    parentId,
  });
};

/**
 * Simulates registering a new teacher.
 */
export const registerTeacher = async (
  teacherName: string,
  email: string,
  subjectsTaught: string[],
  classLevelsTaught: string[],
  phoneNumber: string,
): Promise<{ user: User; password: string }> => {
  return apiCall('/users/register-teacher', 'POST', {
    teacherName,
    email,
    subjectsTaught,
    classLevelsTaught,
    phoneNumber,
  });
};

/**
 * Simulates registering a new parent.
 */
export const registerParent = async (
  parentName: string,
  email: string,
  phoneNumber: string,
  studentIdsToLink?: string[],
): Promise<{ user: User; password: string }> => {
  return apiCall('/users/register-parent', 'POST', {
    parentName,
    email,
    phoneNumber,
    studentIdsToLink,
  });
};

/**
 * Simulates verifying the admin's password to reveal another user's password.
 * This is still handled client-side in terms of password comparison for security reasons
 * in this mock context, but would ideally be a secure backend endpoint returning only
 * access to view the password, not the password itself.
 * For this full-stack migration, we'll keep the client-side `verifyAdminPassword` as is,
 * but real backend systems would have a more complex token-based access.
 * Note: The backend `users` route's GET `/` endpoint can return passwords if `includePasswords=true`.
 * This mock function verifies an admin password, then fetches all users (with passwords)
 * to find the target user's password.
 */
export const verifyAdminPassword = async (adminId: string, adminPasswordInput: string): Promise<boolean> => {
  try {
    const allUsers = await fetchAllUsers(true); // Fetch all users including passwords
    const adminUser = allUsers.find(u => u.id === adminId && u.role === UserRole.Admin);
    if (adminUser && adminUser.password === adminPasswordInput) {
      return true;
    }
    return false;
  } catch (error) {
    console.error('Admin password verification failed via API:', error);
    return false;
  }
};
