
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import Dashboards from './pages/Dashboards';
import FeesPage from './pages/FeesPage';
import TeacherGradesPage from './pages/TeacherGradesPage';
import StudentGradesPage from './pages/StudentGradesPage';
import AdminPage from './pages/AdminPage'; // New Import
import AdminManageClassesPage from './pages/AdminManageClassesPage'; // New Import
import { User, UserRole } from './types';

const AppContent: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('currentUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });
  const navigate = useNavigate();

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      // Redirect to dashboard after login
      if (window.location.hash === '#/login' || window.location.hash === '#/') {
        navigate('/');
      }
    } else {
      localStorage.removeItem('currentUser');
      navigate('/login');
    }
  }, [currentUser, navigate]);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    navigate('/');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    navigate('/login');
  };

  return (
    <Layout user={currentUser} onLogout={handleLogout}>
      <Routes>
        <Route path="/login" element={<LoginPage onLoginSuccess={handleLoginSuccess} />} />
        {currentUser ? (
          <>
            <Route path="/" element={<Dashboards user={currentUser} />} />
            <Route path="/fees" element={<FeesPage user={currentUser} />} />
            {currentUser.role === UserRole.Teacher && (
              <Route path="/teacher/grades" element={<TeacherGradesPage user={currentUser} />} />
            )}
            {currentUser.role === UserRole.Student && (
              <Route path="/student/grades" element={<StudentGradesPage user={currentUser} />} />
            )}
            {currentUser.role === UserRole.Admin && (
              <>
                <Route path="/admin/users" element={<AdminPage user={currentUser} />} />
                <Route path="/admin/manage-classes" element={<AdminManageClassesPage user={currentUser} />} /> {/* New Admin Route */}
              </>
            )}
            {/* Specific routes for other roles can be added here,
                or handled within Dashboards/FeesPage components for simplicity.
                Example:
                <Route path="/student/courses" element={<StudentCoursesPage user={currentUser} />} />
                <Route path="/teacher/classes" element={<TeacherClassesPage user={currentUser} />} />
            */}
            {/* Catch-all route for other paths, redirecting to dashboard */}
            <Route path="*" element={<Dashboards user={currentUser} />} />
          </>
        ) : (
          <Route path="*" element={<LoginPage onLoginSuccess={handleLoginSuccess} />} />
        )}
      </Routes>
    </Layout>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <AppContent />
    </Router>
  );
};

export default App;