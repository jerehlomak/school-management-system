
export enum UserRole {
  Student = 'student',
  Teacher = 'teacher',
  Parent = 'parent',
  Admin = 'admin',
}

export interface User {
  id: string;
  username: string;
  password?: string; // Should not be sent from backend, but for mock login/admin display.
  name: string;
  role: UserRole;
  email: string;
  phoneNumber?: string; // New: For parents and teachers, also used for student passwords
  parentId?: string; // For students, links to parent
  studentIds?: string[]; // For parents, links to students
  classId?: string; // For students, link to their segmented class (e.g., 'JSS1A')
  subjectsEnrolled?: string[]; // For students, list of course IDs they are taking
  subjectsTaught?: string[]; // For teachers, list of course IDs they teach
  classLevelsTaught?: string[]; // For teachers, list of ClassLevel IDs they are associated with (e.g., 'JSS1', 'SSS2')
  admissionYear?: number; // New: For students
}

export interface Course {
  id: string;
  name: string;
  code: string;
  teacherId: string;
  students: string[]; // Student IDs enrolled
}

// New interface for general school year levels (e.g., JSS1, JSS2, SSS1)
export interface ClassLevel {
  id: string;
  name: string; // e.g., "JSS1", "SSS2"
  type: 'JSS' | 'SSS';
  promotedToClassLevelId?: string; // E.g., 'JSS1' -> 'JSS2'
}

// Updated interface for segmented school classes (e.g., JSS1A, JSS1B)
export interface SchoolClass {
  id: string;
  name: string; // e.g., "JSS1A"
  classLevelId: string; // Links to a ClassLevel, e.g., 'JSS1'
  coreSubjects: string[]; // List of course IDs that are mandatory for this class
  optionalSubjects?: {
    group: string; // e.g., "Languages"
    options: string[]; // List of course IDs for optional subjects in this group
    minSelection: number;
    maxSelection: number;
  }[];
}


// New interface for detailed term-based student grades
export interface StudentTermGrade {
  id: string; // Unique ID for this specific term's grade record
  studentId: string;
  courseId: string;
  term: 1 | 2 | 3;
  year: number; // For simplicity, let's assume current year
  assignment1?: number; // Score out of 10 (max)
  assignment2?: number; // Score out of 10 (max)
  test1?: number; // Score out of 20 (max)
  test2?: number; // Score out of 20 (max)
  exam?: number; // Score out of 40 (max)
  totalScore?: number; // Calculated field: sum of weighted scores (out of 100)
  termAverage?: number; // Calculated field: same as totalScore if total max is 100
  termPosition?: string; // Calculated field: e.g., "1st of 30"
  cumulativeAverage?: number; // Calculated for Term 3 only: (Term1_Avg + Term2_Avg + Term3_Avg) / 3
  promotionStatus?: 'Promoted' | 'Not Promoted' | 'N/A'; // For Term 3
  promotedToClass?: string; // For Term 3, e.g., "JSS2C"
  updatedAt: string; // Timestamp of last update
}

export enum PaymentStatus {
  Pending = 'Pending',
  Completed = 'Completed',
  Failed = 'Failed',
}

export interface Payment {
  id: string;
  studentId: string;
  amount: number;
  description: string;
  date: string;
  status: PaymentStatus;
  rrr?: string; // Remita Retrieval Reference
  paymentLink?: string;
}

export interface RRRInfo {
  rrr: string;
  paymentLink: string;
  amount: number;
}
