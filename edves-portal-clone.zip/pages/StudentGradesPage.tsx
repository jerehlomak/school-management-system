import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User, UserRole, StudentTermGrade, Course } from '../types';
import { fetchStudentTermGrades, fetchCourses, fetchAllUsers, fetchClasses } from '../services/apiService'; 
import { MOCK_SCHOOL_DETAILS, getGradeAndRemark } from '../constants'; 
import Table from '../components/Table';
import Button from '../components/Button';
import AIAssistant from '../components/AIAssistant';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface StudentGradesPageProps {
  user: User;
}

interface ReportTableRow {
  subject: string;
  assignment1?: number;
  assignment2?: number;
  test1?: number;
  test2?: number;
  exam?: number;
  totalScore?: number;
  grade: string;
  position: string; // Subject-specific position (simplified to '1' as per OCR)
  remark: string;
}

const CURRENT_YEAR = new Date().getFullYear();

const StudentGradesPage: React.FC<StudentGradesPageProps> = ({ user }) => {
  const [selectedTerm, setSelectedTerm] = useState<1 | 2 | 3>(1);
  const [allStudentGrades, setAllStudentGrades] = useState<StudentTermGrade[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [allClasses, setAllClasses] = useState<any[]>([]); // To get class name for display
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reportCardRef = useRef<HTMLDivElement>(null);

  const loadStudentData = useCallback(async () => {
    if (user.role !== UserRole.Student) {
      setError("Access Denied: Only students can view this page.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const fetchedGrades = await fetchStudentTermGrades(user.id, undefined, undefined, CURRENT_YEAR);
      setAllStudentGrades(fetchedGrades);

      const fetchedCourses = await fetchCourses();
      setCourses(fetchedCourses);

      const fetchedUsers = await fetchAllUsers();
      setAllUsers(fetchedUsers);

      const fetchedClasses = await fetchClasses(); // Fetch classes for lookup
      setAllClasses(fetchedClasses);

    } catch (err: any) {
      console.error('Failed to load student data:', err);
      setError(err.message || 'Failed to load your grades and course information.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadStudentData();
  }, [loadStudentData]);

  // Filter grades for the selected term
  const gradesForSelectedTerm = allStudentGrades.filter(
    (grade) => grade.term === selectedTerm
  ).sort((a, b) => (courses.find(c => c.id === a.courseId)?.name || '').localeCompare(courses.find(c => c.id === b.courseId)?.name || ''));

  // Prepare table data for display and report
  const tableData: ReportTableRow[] = gradesForSelectedTerm.map((grade) => {
    const course = courses.find((c) => c.id === grade.courseId);
    const { grade: letterGrade, remark } = getGradeAndRemark(grade.termAverage);

    return {
      subject: course?.name || `Unknown Course (${grade.courseId})`,
      assignment1: grade.assignment1,
      assignment2: grade.assignment2,
      test1: grade.test1,
      test2: grade.test2,
      exam: grade.exam,
      totalScore: grade.totalScore,
      grade: letterGrade,
      position: letterGrade !== 'F' ? '1' : 'N/A', // Simplified subject position as per OCR example
      remark: remark,
    };
  });

  // Calculate overall summary for the selected term
  const termTotalScores = gradesForSelectedTerm.map(g => g.totalScore || 0);
  const totalSubjects = gradesForSelectedTerm.length;
  const averageScore = totalSubjects > 0 ? (termTotalScores.reduce((sum, score) => sum + score, 0) / totalSubjects).toFixed(2) : 'N/A';

  // For class average and position, we need all grades for the class for the term
  const studentsInClass = allUsers.filter(s => s.role === UserRole.Student && s.classId === user.classId);
  const classAveragesForTerm = studentsInClass.map(s => {
    const studentTermAverage = allStudentGrades.find(g => g.studentId === s.id && g.term === selectedTerm)?.termAverage;
    return studentTermAverage !== undefined ? studentTermAverage : 0;
  }).filter(avg => avg > 0);

  const classAverage = classAveragesForTerm.length > 0
    ? (classAveragesForTerm.reduce((sum, avg) => sum + avg, 0) / classAveragesForTerm.length).toFixed(2)
    : 'N/A';

  const firstGradeInTerm = gradesForSelectedTerm[0];
  const classPositionText = firstGradeInTerm?.termPosition || 'N/A';
  const classPositionMatch = classPositionText.match(/(\d+)(?:st|nd|rd|th) of (\d+)/);
  const positionInClass = classPositionMatch ? `${classPositionMatch[1]} out of ${classPositionMatch[2]}` : 'N/A';


  const cumulativeAverage = (selectedTerm === 3 && firstGradeInTerm?.cumulativeAverage !== undefined)
    ? firstGradeInTerm.cumulativeAverage.toFixed(2)
    : 'N/A';
  const promotionStatus = selectedTerm === 3 ? (firstGradeInTerm?.promotionStatus || 'N/A') : 'N/A';
  const promotedToClass = selectedTerm === 3 ? (firstGradeInTerm?.promotedToClass || 'N/A') : 'N/A';

  const regNo = user.id; 
  const currentClassName = allClasses.find((cls: any) => cls.id === user.classId)?.name || MOCK_SCHOOL_DETAILS.class; // Use fetched class name

  const handlePrint = async () => {
    if (!reportCardRef.current) return;

    const aiAssistant = document.querySelector('.ai-assistant-container');
    const printButton = document.querySelector('.print-button-container');
    if (aiAssistant) aiAssistant.classList.add('hidden');
    if (printButton) printButton.classList.add('hidden');


    const canvas = await html2canvas(reportCardRef.current, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgWidth = 210;
    const pageHeight = 297;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;

    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save(`${user.name.replace(/\s/g, '_')}_Term${selectedTerm}_Report.pdf`);

    if (aiAssistant) aiAssistant.classList.remove('hidden');
    if (printButton) printButton.classList.remove('hidden');
  };

  if (user.role !== UserRole.Student) {
    return <div className="p-6 text-red-600">Access Denied: Only students can access this page.</div>;
  }

  if (loading) {
    return <div className="text-center py-8 text-gray-600">Loading your report card...</div>;
  }

  if (error) {
    return <div className="text-center py-8 text-red-600">{error}</div>;
  }

  const reportColumns = [
    { header: 'SUBJECT', accessor: 'subject' as keyof ReportTableRow, className: 'font-medium text-gray-900 w-[15%]' },
    { header: '1ST ASS (10)', accessor: 'assignment1' as keyof ReportTableRow, className: 'text-center' },
    { header: '2ND ASS (10)', accessor: 'assignment2' as keyof ReportTableRow, className: 'text-center' },
    { header: '1ST TEST (20)', accessor: 'test1' as keyof ReportTableRow, className: 'text-center' },
    { header: '2ND TEST (20)', accessor: 'test2' as keyof ReportTableRow, className: 'text-center' },
    { header: 'EXAM (40)', accessor: 'exam' as keyof ReportTableRow, className: 'text-center' },
    { header: 'TOTAL (100)', accessor: 'totalScore' as keyof ReportTableRow, className: 'font-bold text-center' },
    { header: 'GRADE', accessor: 'grade' as keyof ReportTableRow, className: 'font-bold text-center' },
    { header: 'POSITION', accessor: 'position' as keyof ReportTableRow, className: 'text-center' },
    { header: 'REMARK', accessor: 'remark' as keyof ReportTableRow, className: 'text-left' },
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1 min-w-0">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">My Report Card</h2>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 mb-6 flex flex-col sm:flex-row gap-4 justify-between items-center print-button-container">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <label htmlFor="term-select" className="text-gray-700 font-medium whitespace-nowrap">Select Term:</label>
            <select
              id="term-select"
              value={selectedTerm}
              onChange={(e) => setSelectedTerm(Number(e.target.value) as 1 | 2 | 3)}
              className="flex-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500 sm:w-32"
              disabled={loading}
              aria-label="Select term"
            >
              <option value={1}>First Term</option>
              <option value={2}>Second Term</option>
              <option value={3}>Third Term</option>
            </select>
          </div>
          <Button onClick={handlePrint} variant="primary" className="px-6 py-2.5 w-full sm:w-auto">
            Print Result
          </Button>
        </div>

        <div id="report-card-content" ref={reportCardRef} className="bg-white rounded-lg shadow-md border border-gray-200 p-8 mb-8 print:shadow-none print:border-none print:p-0">
          {/* Report Card Header */}
          <div className="text-center mb-8">
            <div className="flex justify-between items-center mb-4">
                <img src="/cocin_logo_left.png" alt="COCIN Logo" className="h-20 w-auto object-contain" onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/80x80?text=Logo'; }}/>
                <div>
                    <h1 className="text-3xl font-extrabold text-blue-800">{MOCK_SCHOOL_DETAILS.name}</h1>
                    <p className="text-lg text-gray-700">{MOCK_SCHOOL_DETAILS.address}</p>
                    <p className="text-sm italic text-gray-600">{MOCK_SCHOOL_DETAILS.motto}</p>
                </div>
                <img src="/cocin_logo_right.png" alt="COCIN Logo" className="h-20 w-auto object-contain" onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/80x80?text=Logo'; }}/>
            </div>
            <h2 className="text-xl font-bold text-gray-800 border-t pt-2 mt-2">{selectedTerm === 1 ? "FIRST" : selectedTerm === 2 ? "SECOND" : "THIRD"} TERM {CURRENT_YEAR}/{CURRENT_YEAR + 1} ACADEMIC REPORT</h2>
          </div>

          {/* Student Details Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 mb-8 text-gray-700 text-sm">
            <p><span className="font-semibold">Full Name:</span> {user.name}</p>
            <p><span className="font-semibold">Reg No:</span> {regNo}</p>
            <p><span className="font-semibold">Term:</span> {selectedTerm === 1 ? "First" : selectedTerm === 2 ? "Second" : "Third"}</p>
            <p><span className="font-semibold">Session:</span> {MOCK_SCHOOL_DETAILS.session}</p>
            <p><span className="font-semibold">Position in Class:</span> {positionInClass}</p>
            <p><span className="font-semibold">Class Average:</span> {classAverage}</p>
            <p><span className="font-semibold">Cumulative Average:</span> {cumulativeAverage}</p>
            <p><span className="font-semibold">Average Score:</span> {averageScore}</p>
            <p><span className="font-semibold">Promotion Status:</span> {promotionStatus}</p>
            <p><span className="font-semibold">Promoted to Class:</span> {promotedToClass}</p>
            <p><span className="font-semibold">Class:</span> {currentClassName}</p>
            <p><span className="font-semibold">Admission Year:</span> {user.admissionYear || 'N/A'}</p>
            <p><span className="font-semibold">No of Subjects:</span> {totalSubjects}</p>
          </div>

          {/* Grades Table */}
          <div className="mb-8">
            <Table data={tableData} columns={reportColumns} rowKey="subject" emptyMessage="No grades found for this term." />
          </div>

          {/* Grade Analysis & Notes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-gray-700 text-sm">
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Grade Analysis</h3>
              <ul className="list-disc list-inside">
                <li><span className="font-semibold">A</span> 70 - 100</li>
                <li><span className="font-semibold">B</span> 60 - 69</li>
                <li><span className="font-semibold">C</span> 50 - 59</li>
                <li><span className="font-semibold">D</span> 40 - 49</li>
                <li><span className="font-semibold">F</span> 0 - 39</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Note on Grades</h3>
              <p><span className="font-semibold">A (70-100):</span> Excellent Performance</p>
              <p><span className="font-semibold">B (60-69):</span> Very Good</p>
              <p><span className="font-semibold">C (50-59):</span> Good</p>
              <p><span className="font-semibold">D (40-49):</span> Pass</p>
              <p><span className="font-semibold">F (0-39):</span> Fail - Needs Improvement</p>
            </div>
          </div>

          {/* Remarks Section */}
          <div className="mt-8 text-gray-700 text-sm">
            <p className="mb-2"><span className="font-semibold">FORM TEACHER:</span> {MOCK_SCHOOL_DETAILS.teacherName}</p>
            <p className="mb-2"><span className="font-semibold">FORM TEACHER'S REMARK:</span> __________________________________________________</p>
            <p><span className="font-semibold">PRINCIPAL'S REMARK:</span> __________________________________________________</p>
          </div>
        </div>
      </div>

      <div className="w-full lg:w-96 flex-shrink-0 ai-assistant-container">
        <AIAssistant systemInstruction="You are a student academic advisor. Answer questions about grades, academic performance, study tips, or career guidance."/>
      </div>
    </div>
  );
};

export default StudentGradesPage;