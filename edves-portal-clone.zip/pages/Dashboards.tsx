
import React, { useEffect, useState, useCallback } from 'react';
import { User, UserRole, StudentTermGrade, Course, Payment, PaymentStatus } from '../types';
import DashboardCard from '../components/DashboardCard';
import Table from '../components/Table';
import { fetchStudentTermGrades, fetchCourses, fetchStudentPayments, fetchAllUsers, fetchClasses } from '../services/apiService'; // Added fetchClasses
import AIAssistant from '../components/AIAssistant';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import { MOCK_SCHOOL_DETAILS } from '../constants'; // Import MOCK_SCHOOL_DETAILS

interface DashboardsProps {
  user: User;
}

const CURRENT_YEAR = new Date().getFullYear();

const Dashboards: React.FC<DashboardsProps> = ({ user }) => {
  const [studentGrades, setStudentGrades] = useState<StudentTermGrade[]>([]);
  const [studentCourses, setStudentCourses] = useState<Course[]>([]);
  const [studentPayments, setStudentPayments] = useState<Payment[]>([]);
  const [teacherCourses, setTeacherCourses] = useState<Course[]>([]);
  const [teacherAllGrades, setTeacherAllGrades] = useState<StudentTermGrade[]>([]); // To display all grades for a teacher
  const [parentStudents, setParentStudents] = useState<User[]>([]);
  const [adminUsers, setAdminUsers] = useState<User[]>([]);
  const [allFetchedUsers, setAllFetchedUsers] = useState<User[]>([]); // Central store for all users
  const [allFetchedCourses, setAllFetchedCourses] = useState<Course[]>([]); // Central store for all courses
  const [allFetchedClasses, setAllFetchedClasses] = useState<any[]>([]); // Central store for all classes


  const fetchAllData = useCallback(async () => {
    const usersData = await fetchAllUsers(true); // Fetch with passwords for internal linking/details
    setAllFetchedUsers(usersData);
    const coursesData = await fetchCourses();
    setAllFetchedCourses(coursesData);
    const classesData = await fetchClasses();
    setAllFetchedClasses(classesData);
    return { usersData, coursesData, classesData };
  }, []);


  const fetchStudentData = useCallback(async (studentId: string, usersData: User[], coursesData: Course[], classesData: any[]) => {
    const grades = await fetchStudentTermGrades(studentId, undefined, undefined, CURRENT_YEAR);
    setStudentGrades(grades);

    const currentUserData = usersData.find(u => u.id === studentId);
    const enrolledCourseIds = currentUserData?.subjectsEnrolled || [];
    const enrolledCourses = coursesData.filter(course => enrolledCourseIds.includes(course.id));
    setStudentCourses(enrolledCourses);

    const payments = await fetchStudentPayments(studentId);
    setStudentPayments(payments);
  }, []);

  const fetchTeacherData = useCallback(async (teacherId: string, usersData: User[], coursesData: Course[], classesData: any[]) => {
    const teacherUser = usersData.find(u => u.id === teacherId && u.role === UserRole.Teacher);
    if (!teacherUser) {
      setTeacherCourses([]);
      setTeacherAllGrades([]);
      return;
    }

    const coursesTaught = coursesData.filter(course => teacherUser.subjectsTaught?.includes(course.id));
    setTeacherCourses(coursesTaught);

    const allGradesPromises = coursesTaught.flatMap(course =>
      course.students.map(studentId => fetchStudentTermGrades(studentId, course.id, undefined, CURRENT_YEAR))
    );
    const resolvedGrades = await Promise.all(allGradesPromises);
    setTeacherAllGrades(resolvedGrades.flat());
  }, []);

  const fetchParentData = useCallback(async (studentIds: string[], usersData: User[], coursesData: Course[], classesData: any[]) => {
    const studentsLinked = usersData.filter(u => studentIds.includes(u.id) && u.role === UserRole.Student);
    setParentStudents(studentsLinked);
  }, []);

  const fetchAdminData = useCallback(async (usersData: User[], coursesData: Course[], classesData: any[]) => {
    setAdminUsers(usersData);
  }, []);

  useEffect(() => {
    const initializeDashboard = async () => {
        const { usersData, coursesData, classesData } = await fetchAllData();
        if (user.role === UserRole.Student && user.id) {
            fetchStudentData(user.id, usersData, coursesData, classesData);
        } else if (user.role === UserRole.Teacher && user.id) {
            fetchTeacherData(user.id, usersData, coursesData, classesData);
        } else if (user.role === UserRole.Parent && user.studentIds) {
            fetchParentData(user.studentIds, usersData, coursesData, classesData);
        } else if (user.role === UserRole.Admin) {
            fetchAdminData(usersData, coursesData, classesData);
        }
    };
    initializeDashboard();
  }, [user, fetchAllData, fetchStudentData, fetchTeacherData, fetchParentData, fetchAdminData]);


  const renderStudentDashboard = () => {
    const totalCourses = studentCourses.length;
    const overallAverage = studentGrades.length > 0
      ? (studentGrades.filter(g => g.termAverage !== undefined).reduce((sum, g) => sum + (g.termAverage || 0), 0) / studentGrades.filter(g => g.termAverage !== undefined).length).toFixed(2)
      : 'N/A';
    const pendingPayments = studentPayments.filter(p => p.status === PaymentStatus.Pending).length;

    const latestTerm = studentGrades.length > 0 ? Math.max(...studentGrades.map(g => g.term)) : 0;
    const displayGrades = latestTerm > 0 ? studentGrades.filter(g => g.term === latestTerm) : studentGrades;

    const gradesColumns = [
      { header: 'Course', accessor: (row: StudentTermGrade) => allFetchedCourses.find(c => c.id === row.courseId)?.name || row.courseId },
      { header: 'Term', accessor: 'term' as keyof StudentTermGrade },
      { header: 'Total Score', accessor: (row: StudentTermGrade) => row.totalScore?.toFixed(2) ?? 'N/A', className: 'font-semibold' },
      { header: 'Term Average', accessor: (row: StudentTermGrade) => row.termAverage?.toFixed(2) ?? 'N/A', className: 'font-semibold text-blue-700' },
      { header: 'Position', accessor: (row: StudentTermGrade) => row.termPosition || 'N/A' },
      { header: 'Cum. Average', accessor: (row: StudentTermGrade) => row.cumulativeAverage !== undefined ? row.cumulativeAverage.toFixed(2) : 'N/A', className: 'font-semibold text-green-700' },
    ];

    const coursesColumns = [
      { header: 'Course Code', accessor: 'code' as keyof Course },
      { header: 'Course Name', accessor: 'name' as keyof Course },
      { header: 'Teacher', accessor: (row: Course) => allFetchedUsers.find(t => t.id === row.teacherId)?.name || 'N/A' },
    ];

    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Student Dashboard</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <DashboardCard
            title="Total Courses"
            value={totalCourses}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>}
          />
          <DashboardCard
            title="Overall Average"
            value={overallAverage}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>}
          />
          <DashboardCard
            title="Pending Payments"
            value={pendingPayments}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2V7a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>}
          />
        </div>

        <section className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">My Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-gray-700">
            <p><span className="font-semibold">Student ID:</span> {user.id}</p>
            <p><span className="font-semibold">Class:</span> {allFetchedClasses.find((cls: any) => cls.id === user.classId)?.name || 'N/A'}</p>
            <p><span className="font-semibold">Admission Year:</span> {user.admissionYear || 'N/A'}</p>
            <p><span className="font-semibold">Email:</span> {user.email}</p>
            <p><span className="font-semibold">Parent:</span> {allFetchedUsers.find(p => p.id === user.parentId)?.name || 'N/A'}</p>
            <p><span className="font-semibold">Phone:</span> {user.phoneNumber || 'N/A'}</p>
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center justify-between">
            My Grades Overview ({CURRENT_YEAR})
            <Link to="/student/grades">
              <Button variant="ghost" size="sm">
                View Full Report Card
              </Button>
            </Link>
          </h3>
          <Table data={displayGrades} columns={gradesColumns} rowKey="id" emptyMessage="No grades recorded yet." />
        </section>

        <section>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">My Courses</h3>
          <Table data={studentCourses} columns={coursesColumns} rowKey="id" emptyMessage="No courses enrolled yet." />
        </section>
      </div>
    );
  };

  const renderTeacherDashboard = () => {
    const totalClasses = teacherCourses.length;
    const totalStudents = new Set(teacherCourses.flatMap(c => c.students)).size;
    const gradesEntered = teacherAllGrades.length;

    const coursesColumns = [
      { header: 'Course Code', accessor: 'code' as keyof Course },
      { header: 'Course Name', accessor: 'name' as keyof Course },
      { header: 'Enrolled Students', accessor: (row: Course) => row.students.length },
      { header: 'Assigned Teacher', accessor: (row: Course) => allFetchedUsers.find(t => t.id === row.teacherId)?.name || 'N/A' },
    ];

    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Teacher Dashboard</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <DashboardCard
            title="Classes Taught"
            value={totalClasses}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"></path></svg>}
          />
          <DashboardCard
            title="Total Students"
            value={totalStudents}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H2v-2a3 3 0 005.356-1.857M9 20v-2a3 3 0 013-3m-4.75 0V7a4.5 4.5 0 119 0v10M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>}
          />
          <DashboardCard
            title="Grades Entered"
            value={gradesEntered}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>}
          />
        </div>

        <section className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">My Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-gray-700">
            <p><span className="font-semibold">Teacher ID:</span> {user.id}</p>
            <p><span className="font-semibold">Phone:</span> {user.phoneNumber || 'N/A'}</p>
            <p><span className="font-semibold">Email:</span> {user.email}</p>
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">My Courses</h3>
          <Table data={teacherCourses} columns={coursesColumns} rowKey="id" emptyMessage="No courses assigned yet." />
        </section>
      </div>
    );
  };

  const renderParentDashboard = () => {
    const totalChildren = parentStudents.length;
    const mockOutstandingFees = 50000 * totalChildren;

    const studentColumns = [
      { header: 'Student Name', accessor: 'name' as keyof User },
      { header: 'Student ID', accessor: 'id' as keyof User },
      { header: 'Email', accessor: 'email' as keyof User },
      { header: 'Phone No.', accessor: (row: User) => row.phoneNumber || 'N/A' },
      { header: 'Class', accessor: (row: User) => allFetchedClasses.find((cls: any) => cls.id === row.classId)?.name || 'N/A' },
      { header: 'Admission Year', accessor: (row: User) => row.admissionYear || 'N/A' },
    ];

    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Parent Dashboard</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <DashboardCard
            title="Children Enrolled"
            value={totalChildren}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H2v-2a3 3 0 005.356-1.857M9 20v-2a3 3 0 013-3m-4.75 0V7a4.5 4.5 0 119 0v10M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>}
          />
          <DashboardCard
            title="Outstanding Fees"
            value={`₦${mockOutstandingFees.toLocaleString()}`}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 8h6m-5 0h.01M9 12h6m-5 0h.01M9 16h6m-5 0h.01M16 3H8a2 2 0 00-2 2v14a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2z"></path></svg>}
          />
          <DashboardCard
            title="Upcoming Events"
            value="3"
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>}
          />
        </div>

        <section className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">My Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-gray-700">
            <p><span className="font-semibold">Parent ID:</span> {user.id}</p>
            <p><span className="font-semibold">Phone:</span> {user.phoneNumber || 'N/A'}</p>
            <p><span className="font-semibold">Email:</span> {user.email}</p>
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">My Children</h3>
          <Table data={parentStudents} columns={studentColumns} rowKey="id" emptyMessage="No children linked." />
        </section>
      </div>
    );
  };

  const renderAdminDashboard = () => {
    const totalUsers = adminUsers.length;
    const totalStudents = adminUsers.filter(u => u.role === UserRole.Student).length;
    const totalTeachers = adminUsers.filter(u => u.role === UserRole.Teacher).length;
    const totalParents = adminUsers.filter(u => u.role === UserRole.Parent).length;


    const userColumns = [
      { header: 'Name', accessor: 'name' as keyof User },
      { header: 'Username', accessor: 'username' as keyof User },
      { header: 'Email', accessor: 'email' as keyof User },
      { header: 'Role', accessor: 'role' as keyof User },
    ];

    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Admin Dashboard</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <DashboardCard
            title="Total Users"
            value={totalUsers}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292V15a2 2 0 01-2 2H8a2 2 0 01-2-2v-4.646m8 0V15a2 2 0 002 2h2a2 2 0 002-2v-4.646M12 18.535V22"></path></svg>}
          />
          <DashboardCard
            title="Total Students"
            value={totalStudents}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM12 18v-1a2 2 0 00-2-2H7a2 2 0 00-2 2v1"></path></svg>}
          />
          <DashboardCard
            title="Total Teachers"
            value={totalTeachers}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H2v-2a3 3 0 005.356-1.857M9 20v-2a3 3 0 013-3m-4.75 0V7a4.5 4.5 0 119 0v10M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>}
          />
          <DashboardCard
            title="Total Parents"
            value={totalParents}
            icon={<svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 18.72a4.5 4.5 0 002.2-.97m0 0a4.5 4.5 0 00-2.2-.97m0 0H12m4.053 4.908a2.91 2.91 0 002.868-.262M18 18.72c-1.353-.193-2.636-.534-3.832-1.018M7.89 18.72a4.5 4.5 0 01-2.2-.97m0 0a4.5 4.5 0 012.2-.97m0 0H12m-.868 4.908a2.91 2.91 0 01-2.868-.262M6 18.72c1.353-.193 2.636-.534 3.832-1.018m0 0a3 3 0 012.236-1.956M11.999 4.418c-2.34-.14-4.26-1.32-5.594-3.15M12 21.082a9 9 0 100-18 9 9 0 000 18z"></path></svg>}
          />
        </div>

        <section>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">All Users</h3>
          <Table data={adminUsers} columns={userColumns} rowKey="id" emptyMessage="No users found." />
        </section>
      </div>
    );
  };

  const renderDashboardContent = () => {
    switch (user.role) {
      case UserRole.Student:
        return renderStudentDashboard();
      case UserRole.Teacher:
        return renderTeacherDashboard();
      case UserRole.Parent:
        return renderParentDashboard();
      case UserRole.Admin:
        return renderAdminDashboard();
      default:
        return <p className="text-gray-600">Welcome to your dashboard!</p>;
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1">
        {renderDashboardContent()}
      </div>
      <div className="w-full lg:w-96 flex-shrink-0">
        <AIAssistant />
      </div>
    </div>
  );
};

export default Dashboards;