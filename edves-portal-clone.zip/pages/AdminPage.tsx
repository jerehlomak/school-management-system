
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { User, UserRole, Course, SchoolClass, ClassLevel } from '../types';
import { fetchAllUsers, registerStudent, registerTeacher, registerParent, fetchCourses, fetchClasses, fetchClassLevels, fetchStudentsWithoutParents, verifyAdminPassword } from '../services/apiService';
import Table from '../components/Table';
import Button from '../components/Button';
import AIAssistant from '../components/AIAssistant';
import Modal from '../components/Modal';
// Removed MOCK_COURSES and MOCK_CLASS_LEVELS from constants as they are now dynamically fetched or for static display configuration.
// import { MOCK_COURSES, MOCK_CLASS_LEVELS } from '../constants'; 

interface AdminPageProps {
  user: User;
}

const AdminPage: React.FC<AdminPageProps> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'registerStudent' | 'registerTeacher' | 'registerParent' | 'manageUsers' | 'manageClasses'>('manageUsers');
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]); // For role filtering
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<UserRole | 'all'>('all'); // State for role filter
  const [courses, setCourses] = useState<Course[]>([]); // All courses from DB
  const [classes, setClasses] = useState<SchoolClass[]>([]); // All classes from DB
  const [classLevels, setClassLevels] = useState<ClassLevel[]>([]); // All class levels from DB
  const [studentsWithoutParents, setStudentsWithoutParents] = useState<User[]>([]); // For parent linking
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Student Registration Form States
  const [studentName, setStudentName] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [studentClassId, setStudentClassId] = useState('');
  const [studentAdmissionYear, setStudentAdmissionYear] = useState<number | ''>(new Date().getFullYear()); // New
  const [selectedParentId, setSelectedParentId] = useState<string>(''); // New
  const [selectedCoreSubjects, setSelectedCoreSubjects] = useState<string[]>([]);
  const [selectedOptionalSubjects, setSelectedOptionalSubjects] = useState<string[]>([]);
  const [studentRegistrationLoading, setStudentRegistrationLoading] = useState(false);
  const [newStudentCredentials, setNewStudentCredentials] = useState<{ id: string, password: string } | null>(null);

  // Teacher Registration Form States
  const [teacherName, setTeacherName] = useState('');
  const [teacherEmail, setTeacherEmail] = useState('');
  const [teacherPhoneNumber, setTeacherPhoneNumber] = useState(''); // New
  const [selectedSubjectsTaught, setSelectedSubjectsTaught] = useState<string[]>([]);
  const [selectedClassLevelsTaught, setSelectedClassLevelsTaught] = useState<string[]>([]);
  const [teacherRegistrationLoading, setTeacherRegistrationLoading] = useState(false);
  const [newTeacherCredentials, setNewTeacherCredentials] = useState<{ id: string, password: string } | null>(null);

  // Parent Registration Form States
  const [parentName, setParentName] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [parentPhoneNumber, setParentPhoneNumber] = useState('');
  const [parentStudentsToLink, setParentStudentsToLink] = useState<string[]>([]); // Student IDs to link
  const [parentRegistrationLoading, setParentRegistrationLoading] = useState(false);
  const [newParentCredentials, setNewParentCredentials] = useState<{ id: string, password: string } | null>(null);

  // Password Reveal States
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [passwordVerificationError, setPasswordVerificationError] = useState<string | null>(null);
  const [revealedPasswordId, setRevealedPasswordId] = useState<string | null>(null);
  const [revealTimeoutId, setRevealTimeoutId] = useState<number | null>(null);
  const [tempPassword, setTempPassword] = useState<string | null>(null);


  const loadInitialData = useCallback(async () => {
    setLoading(true);
    try {
      const fetchedUsers = await fetchAllUsers(true); // Fetch with passwords for admin view
      setUsers(fetchedUsers);

      const fetchedCourses = await fetchCourses();
      setCourses(fetchedCourses);

      const fetchedClasses = await fetchClasses();
      setClasses(fetchedClasses);

      const fetchedClassLevels = await fetchClassLevels();
      setClassLevels(fetchedClassLevels);

      const studentsWithoutParents = await fetchStudentsWithoutParents();
      setStudentsWithoutParents(studentsWithoutParents);

    } catch (err) {
      console.error('Failed to load initial data:', err);
      setMessage({ type: 'error', text: 'Failed to load initial data.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user.role === UserRole.Admin) {
      loadInitialData();
    }
  }, [user.role, loadInitialData]);

  // Apply filtering whenever users or filter changes
  useEffect(() => {
    let currentFilteredUsers = users;
    if (selectedRoleFilter !== 'all') {
      currentFilteredUsers = users.filter(u => u.role === selectedRoleFilter);
    }
    setFilteredUsers(currentFilteredUsers);
  }, [users, selectedRoleFilter]);


  // Derived state for subjects based on selected class
  const selectedClass = useMemo(() => classes.find(c => c.id === studentClassId), [studentClassId, classes]);
  const availableCoreSubjects = useMemo(() => {
    if (!selectedClass) return [];
    // Filter from fetched 'courses' state, not MOCK_COURSES
    return courses.filter(course => selectedClass.coreSubjects.includes(course.id));
  }, [selectedClass, courses]);
  const availableOptionalSubjectGroups = useMemo(() => {
    if (!selectedClass || !selectedClass.optionalSubjects) return [];
    return selectedClass.optionalSubjects.map(group => ({
      ...group,
      options: courses.filter(course => group.options.includes(course.id))
    }));
  }, [selectedClass, courses]);

  const parentsList = useMemo(() => {
    return users.filter(u => u.role === UserRole.Parent);
  }, [users]);


  const handleStudentRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setStudentRegistrationLoading(true);
    setMessage(null);
    setNewStudentCredentials(null);

    // Form validation
    if (!studentName.trim() || !studentEmail.trim() || !studentClassId || !studentAdmissionYear || !selectedParentId) {
      setMessage({ type: 'error', text: 'Please fill in all required student fields, including Admission Year and selecting a Parent.' });
      setStudentRegistrationLoading(false);
      return;
    }
    if (!selectedClass) {
        setMessage({ type: 'error', text: 'Please select a valid class.' });
        setStudentRegistrationLoading(false);
        return;
    }
    
    const allSubjectsEnrolled = [...selectedCoreSubjects, ...selectedOptionalSubjects];

    // Validate optional language selection (if any group is configured for it)
    const languageGroup = availableOptionalSubjectGroups.find(g => g.group === 'Languages');
    if (languageGroup) {
      const selectedLanguages = selectedOptionalSubjects.filter(subId => languageGroup.options.some(opt => opt.id === subId));
      if (selectedLanguages.length < languageGroup.minSelection || selectedLanguages.length > languageGroup.maxSelection) {
        setMessage({ type: 'error', text: `You must select exactly one language from the optional languages.` });
        setStudentRegistrationLoading(false);
        return;
      }
    }
    
    try {
      const { user: newStudent, password: studentPassword } = await registerStudent(
        studentName,
        studentEmail,
        studentClassId,
        allSubjectsEnrolled,
        studentAdmissionYear as number, // Cast as number since it's validated
        selectedParentId
      );
      setMessage({ type: 'success', text: `Student ${newStudent.name} registered successfully! ID: ${newStudent.id}` });
      setNewStudentCredentials({ id: newStudent.id, password: studentPassword });
      // Reset form
      setStudentName('');
      setStudentEmail('');
      setStudentClassId('');
      setStudentAdmissionYear(new Date().getFullYear());
      setSelectedParentId('');
      setSelectedCoreSubjects([]);
      setSelectedOptionalSubjects([]);
      loadInitialData(); // Refresh user list and parent data
    } catch (err: any) {
      console.error('Student registration failed:', err);
      setMessage({ type: 'error', text: err.message || 'Failed to register student.' });
    } finally {
      setStudentRegistrationLoading(false);
    }
  };

  const handleTeacherRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setTeacherRegistrationLoading(true);
    setMessage(null);
    setNewTeacherCredentials(null);

    if (!teacherName.trim() || !teacherEmail.trim() || !teacherPhoneNumber.trim() || selectedSubjectsTaught.length === 0 || selectedClassLevelsTaught.length === 0) {
      setMessage({ type: 'error', text: 'Please fill in all required teacher fields, including phone number, and select at least one subject and one class level.' });
      setTeacherRegistrationLoading(false);
      return;
    }

    try {
      const { user: newTeacher, password: teacherPassword } = await registerTeacher(
        teacherName,
        teacherEmail,
        selectedSubjectsTaught,
        selectedClassLevelsTaught,
        teacherPhoneNumber
      );
      setMessage({ type: 'success', text: `Teacher ${newTeacher.name} registered successfully! ID: ${newTeacher.id}` });
      setNewTeacherCredentials({ id: newTeacher.id, password: teacherPassword });
      // Reset form
      setTeacherName('');
      setTeacherEmail('');
      setTeacherPhoneNumber('');
      setSelectedSubjectsTaught([]);
      setSelectedClassLevelsTaught([]);
      loadInitialData(); // Refresh user list
    } catch (err: any) {
      console.error('Teacher registration failed:', err);
      setMessage({ type: 'error', text: err.message || 'Failed to register teacher.' });
    } finally {
      setTeacherRegistrationLoading(false);
    }
  };

  const handleParentRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setParentRegistrationLoading(true);
    setMessage(null);
    setNewParentCredentials(null);

    if (!parentName.trim() || !parentEmail.trim() || !parentPhoneNumber.trim()) {
      setMessage({ type: 'error', text: 'Please fill in all required parent fields, including phone number.' });
      setParentRegistrationLoading(false);
      return;
    }

    try {
      const { user: newParent, password: parentPassword } = await registerParent(
        parentName,
        parentEmail,
        parentPhoneNumber,
        parentStudentsToLink.length > 0 ? parentStudentsToLink : undefined
      );
      setMessage({ type: 'success', text: `Parent ${newParent.name} registered successfully! ID: ${newParent.id}` });
      setNewParentCredentials({ id: newParent.id, password: parentPassword });
      // Reset form
      setParentName('');
      setParentEmail('');
      setParentPhoneNumber('');
      setParentStudentsToLink([]);
      loadInitialData(); // Refresh user list and students without parents
    } catch (err: any) {
      console.error('Parent registration failed:', err);
      setMessage({ type: 'error', text: err.message || 'Failed to register parent.' });
    } finally {
      setParentRegistrationLoading(false);
    }
  };


  const handleShowPasswordClick = (targetUserId: string) => {
    setRevealedPasswordId(targetUserId);
    setIsPasswordModalOpen(true);
    setPasswordVerificationError(null);
    setAdminPasswordInput('');
    setTempPassword(null); // Clear any previously revealed password
    if (revealTimeoutId) {
      clearTimeout(revealTimeoutId);
      setRevealTimeoutId(null);
    }
  };

  const handleAdminPasswordVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminPasswordInput.trim()) {
      setPasswordVerificationError('Please enter your admin password.');
      return;
    }

    setLoading(true);
    setPasswordVerificationError(null);
    try {
      // API call now to verify admin password, which also fetches users with passwords
      const isValid = await verifyAdminPassword(user.id, adminPasswordInput);
      if (isValid) {
        // Fetch all users again with passwords to ensure latest data
        const fetchedUsersWithPasswords = await fetchAllUsers(true); 
        const targetUser = fetchedUsersWithPasswords.find(u => u.id === revealedPasswordId);

        if (targetUser && targetUser.password) {
          setTempPassword(targetUser.password);
          // Hide password after 10 seconds
          const timeout = window.setTimeout(() => {
            setTempPassword(null);
            setRevealedPasswordId(null);
          }, 10000);
          setRevealTimeoutId(timeout);
          setIsPasswordModalOpen(false); // Close the modal
        } else {
          setPasswordVerificationError('User or password not found.');
        }
      } else {
        setPasswordVerificationError('Incorrect admin password.');
      }
    } catch (err) {
      console.error('Admin password verification failed:', err);
      setPasswordVerificationError('Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getUserPasswordDisplay = (targetUserId: string) => {
    if (revealedPasswordId === targetUserId && tempPassword) {
      return (
        <span className="font-mono text-green-700 bg-green-50 px-2 py-1 rounded-md text-xs">
          {tempPassword}
        </span>
      );
    }
    return (
      <Button
        onClick={() => handleShowPasswordClick(targetUserId)}
        variant="ghost"
        size="sm"
        className="text-blue-600 hover:text-blue-800"
        aria-label={`Show password for ${targetUserId}`}
      >
        Show Password
      </Button>
    );
  };

  const userColumns = useMemo(() => ([
    { header: 'ID', accessor: 'id' as keyof User, className: 'font-semibold' },
    { header: 'Name', accessor: 'name' as keyof User },
    { header: 'Username', accessor: 'username' as keyof User },
    { header: 'Email', accessor: 'email' as keyof User },
    { header: 'Phone No.', accessor: (row: User) => row.phoneNumber || 'N/A' }, // New column
    { header: 'Role', accessor: 'role' as keyof User },
    { header: 'Details', accessor: (row: User) => {
        if (row.role === UserRole.Student) {
          // Access 'classes' and 'courses' from state, not global mocks
          const className = classes.find(c => c.id === row.classId)?.name || row.classId;
          const subjects = row.subjectsEnrolled?.map(subId => courses.find(c => c.id === subId)?.code).filter(Boolean).join(', ');
          const parentName = row.parentId ? users.find(p => p.id === row.parentId)?.name : 'N/A';
          return (
            <div className="text-xs">
              <p>Class: {className || 'N/A'}</p>
              <p>Adm. Year: {row.admissionYear || 'N/A'}</p>
              <p>Parent: {parentName}</p>
              <p>Subjects: {subjects || 'No Subjects'}</p>
            </div>
          );
        } else if (row.role === UserRole.Teacher) {
          const taughtSubjects = row.subjectsTaught?.map(subId => courses.find(c => c.id === subId)?.code).filter(Boolean).join(', ');
          const taughtClassLevels = row.classLevelsTaught?.map(clId => classLevels.find(cl => cl.id === clId)?.name).filter(Boolean).join(', ');
          return (
            <div className="text-xs">
              <p>Teaches: {taughtSubjects || 'N/A'}</p>
              <p>Class Levels: {taughtClassLevels || 'N/A'}</p>
            </div>
          );
        } else if (row.role === UserRole.Parent && row.studentIds) {
          const studentNames = row.studentIds.map(sId => users.find(u => u.id === sId)?.name || sId).join(', ');
          return `Children: ${studentNames || 'None'}`;
        }
        return 'N/A';
      }
    },
    { header: 'Password', accessor: (row: User) => getUserPasswordDisplay(row.id) },
  ]), [classes, courses, classLevels, revealedPasswordId, tempPassword, users]); // Added users to dependencies for parent student names

  if (user.role !== UserRole.Admin) {
    return <div className="p-6 text-red-600">Access Denied: Only administrators can access this page.</div>;
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Admin Panel</h2>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 mb-6">
          <div className="flex space-x-4 border-b border-gray-200 mb-4">
            <button
              onClick={() => setActiveTab('registerStudent')}
              className={`py-2 px-4 text-sm font-medium ${activeTab === 'registerStudent' ? 'text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Register Student
            </button>
            <button
              onClick={() => setActiveTab('registerTeacher')}
              className={`py-2 px-4 text-sm font-medium ${activeTab === 'registerTeacher' ? 'text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Register Teacher
            </button>
            <button
              onClick={() => setActiveTab('registerParent')}
              className={`py-2 px-4 text-sm font-medium ${activeTab === 'registerParent' ? 'text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Register Parent
            </button>
            <button
              onClick={() => setActiveTab('manageUsers')}
              className={`py-2 px-4 text-sm font-medium ${activeTab === 'manageUsers' ? 'text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Manage Users
            </button>
            <button
              onClick={() => setActiveTab('manageClasses')}
              className={`py-2 px-4 text-sm font-medium ${activeTab === 'manageClasses' ? 'text-blue-700 border-b-2 border-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Manage Classes
            </button>
          </div>

          {message && (
            <div
              className={`p-3 rounded-lg text-white mb-4 ${
                message.type === 'success' ? 'bg-green-500' : 'bg-red-500'
              }`}
              role="alert"
            >
              {message.text}
            </div>
          )}

          {activeTab === 'registerStudent' && (
            <form onSubmit={handleStudentRegistration} className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">New Student Registration</h3>
              <div>
                <label htmlFor="student-name" className="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" id="student-name" value={studentName} onChange={(e) => setStudentName(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div>
                <label htmlFor="student-email" className="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" id="student-email" value={studentEmail} onChange={(e) => setStudentEmail(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div>
                <label htmlFor="student-admission-year" className="block text-sm font-medium text-gray-700">Admission Year</label>
                <input type="number" id="student-admission-year" value={studentAdmissionYear} onChange={(e) => setStudentAdmissionYear(Number(e.target.value))} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" min="1900" max={new Date().getFullYear()} />
              </div>
              <div>
                <label htmlFor="student-class" className="block text-sm font-medium text-gray-700">Class</label>
                <select id="student-class" value={studentClassId} onChange={(e) => {
                  setStudentClassId(e.target.value);
                  const newSelectedClass = classes.find(c => c.id === e.target.value);
                  if (newSelectedClass) {
                      setSelectedCoreSubjects(newSelectedClass.coreSubjects);
                  } else {
                      setSelectedCoreSubjects([]);
                  }
                  setSelectedOptionalSubjects([]);
                }} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md">
                  <option value="">Select Class</option>
                  {classes.map(cls => (
                    <option key={cls.id} value={cls.id}>{cls.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="student-parent" className="block text-sm font-medium text-gray-700">Link Parent</label>
                <select id="student-parent" value={selectedParentId} onChange={(e) => setSelectedParentId(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md">
                  <option value="">Select Parent</option>
                  {parentsList.map(parent => (
                    <option key={parent.id} value={parent.id}>{parent.name} ({parent.email})</option>
                  ))}
                </select>
                {selectedParentId && (
                  <p className="mt-2 text-sm text-gray-600">
                    Student's password and phone number will be set to the selected parent's phone number: <span className="font-semibold">{parentsList.find(p => p.id === selectedParentId)?.phoneNumber || 'N/A'}</span>
                  </p>
                )}
                {parentsList.length === 0 && (
                  <p className="mt-2 text-sm text-red-500">
                    No parents registered. Please register a parent first in the "Register Parent" tab.
                  </p>
                )}
              </div>

              {selectedClass && (
                <>
                  <div className="border p-4 rounded-md bg-gray-50">
                    <h4 className="font-semibold text-gray-800 mb-2">Core Subjects for {selectedClass.name}</h4>
                    {availableCoreSubjects.length > 0 ? (
                      <div className="space-y-1">
                        {availableCoreSubjects.map(course => (
                          <div key={course.id} className="flex items-center">
                            <input
                              type="checkbox"
                              id={`core-${course.id}`}
                              checked={selectedCoreSubjects.includes(course.id)} // Reflect dynamic core subjects
                              disabled={true}
                              className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                            />
                            <label htmlFor={`core-${course.id}`} className="ml-2 text-sm text-gray-700">{course.name} ({course.code})</label>
                          </div>
                        ))}
                      </div>
                    ) : <p className="text-sm text-gray-600">No core subjects defined for this class.</p>}
                  </div>

                  {availableOptionalSubjectGroups.map(group => (
                    <div key={group.group} className="border p-4 rounded-md bg-gray-50">
                      <h4 className="font-semibold text-gray-800 mb-2">
                        {group.group} (Select {group.minSelection} to {group.maxSelection})
                      </h4>
                      {group.options.length > 0 ? (
                        <div className="space-y-1">
                          {group.options.map(course => (
                            <div key={course.id} className="flex items-center">
                              <input
                                type="checkbox"
                                id={`optional-${course.id}`}
                                checked={selectedOptionalSubjects.includes(course.id)}
                                onChange={(e) => {
                                  setSelectedOptionalSubjects(prev => {
                                    if (e.target.checked) {
                                      // If already at max, and this is a new selection in a restrictive group, prevent adding
                                      if (group.maxSelection === 1 && prev.filter(subId => group.options.some(opt => opt.id === subId)).length >= 1) {
                                          // If max is 1, replace the existing selection in this group
                                          const filteredPrev = prev.filter(subId => !group.options.some(opt => opt.id === subId));
                                          return [...filteredPrev, course.id];
                                      }
                                      return [...prev, course.id];
                                    } else {
                                      return prev.filter(id => id !== course.id);
                                    }
                                  });
                                }}
                                className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                              />
                              <label htmlFor={`optional-${course.id}`} className="ml-2 text-sm text-gray-700">{course.name} ({course.code})</label>
                            </div>
                          ))}
                        </div>
                      ) : <p className="text-sm text-gray-600">No optional subjects in this group.</p>}
                    </div>
                  ))}
                </>
              )}

              <Button type="submit" loading={studentRegistrationLoading} className="w-full">
                Register Student
              </Button>
              {newStudentCredentials && (
                <div className="mt-4 p-3 bg-blue-50 text-blue-800 rounded-md">
                  <p className="font-semibold">Student Registered!</p>
                  <p>ID: <span className="font-mono">{newStudentCredentials.id}</span></p>
                  <p>Password (Parent Phone No.): <span className="font-mono">{newStudentCredentials.password}</span></p>
                  <p className="text-sm mt-1">Please note these credentials securely.</p>
                </div>
              )}
            </form>
          )}

          {activeTab === 'registerTeacher' && (
            <form onSubmit={handleTeacherRegistration} className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">New Teacher Registration</h3>
              <div>
                <label htmlFor="teacher-name" className="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" id="teacher-name" value={teacherName} onChange={(e) => setTeacherName(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div>
                <label htmlFor="teacher-email" className="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" id="teacher-email" value={teacherEmail} onChange={(e) => setTeacherEmail(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div>
                <label htmlFor="teacher-phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
                <input type="tel" id="teacher-phone" value={teacherPhoneNumber} onChange={(e) => setTeacherPhoneNumber(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div className="border p-4 rounded-md bg-gray-50">
                <h4 className="font-semibold text-gray-800 mb-2">Subjects Taught</h4>
                {courses.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {courses.map(course => (
                      <div key={course.id} className="flex items-center">
                        <input
                          type="checkbox"
                          id={`teacher-subject-${course.id}`}
                          checked={selectedSubjectsTaught.includes(course.id)}
                          onChange={(e) => {
                            setSelectedSubjectsTaught(prev =>
                              e.target.checked ? [...prev, course.id] : prev.filter(id => id !== course.id)
                            );
                          }}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                        />
                        <label htmlFor={`teacher-subject-${course.id}`} className="ml-2 text-sm text-gray-700">{course.name} ({course.code})</label>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-gray-600">No subjects available.</p>}
              </div>

              <div className="border p-4 rounded-md bg-gray-50">
                <h4 className="font-semibold text-gray-800 mb-2">Class Levels Taught</h4>
                {classLevels.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {classLevels.map(classLevel => (
                      <div key={classLevel.id} className="flex items-center">
                        <input
                          type="checkbox"
                          id={`teacher-class-level-${classLevel.id}`}
                          checked={selectedClassLevelsTaught.includes(classLevel.id)}
                          onChange={(e) => {
                            setSelectedClassLevelsTaught(prev =>
                              e.target.checked ? [...prev, classLevel.id] : prev.filter(id => id !== classLevel.id)
                            );
                          }}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                        />
                        <label htmlFor={`teacher-class-level-${classLevel.id}`} className="ml-2 text-sm text-gray-700">{classLevel.name}</label>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-gray-600">No class levels available.</p>}
              </div>

              <Button type="submit" loading={teacherRegistrationLoading} className="w-full">
                Register Teacher
              </Button>
              {newTeacherCredentials && (
                <div className="mt-4 p-3 bg-blue-50 text-blue-800 rounded-md">
                  <p className="font-semibold">Teacher Registered!</p>
                  <p>ID: <span className="font-mono">{newTeacherCredentials.id}</span></p>
                  <p>Password: <span className="font-mono">{newTeacherCredentials.password}</span></p>
                  <p className="text-sm mt-1">Please note these credentials securely.</p>
                </div>
              )}
            </form>
          )}

          {activeTab === 'registerParent' && (
            <form onSubmit={handleParentRegistration} className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">New Parent Registration</h3>
              <div>
                <label htmlFor="parent-name" className="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" id="parent-name" value={parentName} onChange={(e) => setParentName(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div>
                <label htmlFor="parent-email" className="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" id="parent-email" value={parentEmail} onChange={(e) => setParentEmail(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
              </div>
              <div>
                <label htmlFor="parent-phone" className="block text-sm font-medium text-gray-700">Phone Number (Also used for student passwords)</label>
                <input type="tel" id="parent-phone" value={parentPhoneNumber} onChange={(e) => setParentPhoneNumber(e.target.value)} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md" pattern="[0-9]{10,11}" title="Phone number must be 10 or 11 digits" />
              </div>
              <div className="border p-4 rounded-md bg-gray-50">
                <h4 className="font-semibold text-gray-800 mb-2">Link Existing Students (Optional)</h4>
                {studentsWithoutParents.length > 0 ? (
                  <div className="space-y-1">
                    {studentsWithoutParents.map(student => (
                      <div key={student.id} className="flex items-center">
                        <input
                          type="checkbox"
                          id={`link-student-${student.id}`}
                          checked={parentStudentsToLink.includes(student.id)}
                          onChange={(e) => {
                            setParentStudentsToLink(prev =>
                              e.target.checked ? [...prev, student.id] : prev.filter(id => id !== student.id)
                            );
                          }}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                        />
                        <label htmlFor={`link-student-${student.id}`} className="ml-2 text-sm text-gray-700">{student.name} ({student.id})</label>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-gray-600">No unlinked students found.</p>}
              </div>

              <Button type="submit" loading={parentRegistrationLoading} className="w-full">
                Register Parent
              </Button>
              {newParentCredentials && (
                <div className="mt-4 p-3 bg-blue-50 text-blue-800 rounded-md">
                  <p className="font-semibold">Parent Registered!</p>
                  <p>ID: <span className="font-mono">{newParentCredentials.id}</span></p>
                  <p>Password: <span className="font-mono">{newParentCredentials.password}</span></p>
                  <p className="text-sm mt-1">Please note these credentials securely.</p>
                </div>
              )}
            </form>
          )}

          {activeTab === 'manageUsers' && (
            <div className="space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">All Users</h3>
              <div className="mb-4 flex space-x-2">
                <Button variant={selectedRoleFilter === 'all' ? 'primary' : 'secondary'} size="sm" onClick={() => setSelectedRoleFilter('all')}>All ({users.length})</Button>
                <Button variant={selectedRoleFilter === UserRole.Student ? 'primary' : 'secondary'} size="sm" onClick={() => setSelectedRoleFilter(UserRole.Student)}>Students ({users.filter(u => u.role === UserRole.Student).length})</Button>
                <Button variant={selectedRoleFilter === UserRole.Teacher ? 'primary' : 'secondary'} size="sm" onClick={() => setSelectedRoleFilter(UserRole.Teacher)}>Teachers ({users.filter(u => u.role === UserRole.Teacher).length})</Button>
                <Button variant={selectedRoleFilter === UserRole.Parent ? 'primary' : 'secondary'} size="sm" onClick={() => setSelectedRoleFilter(UserRole.Parent)}>Parents ({users.filter(u => u.role === UserRole.Parent).length})</Button>
              </div>
              <Table data={filteredUsers} columns={userColumns} rowKey="id" emptyMessage="No users found." />
            </div>
          )}

          {activeTab === 'manageClasses' && (
             <div className="space-y-6">
               <h3 className="text-xl font-semibold text-gray-800">Manage Classes (Coming Soon!)</h3>
               <p className="text-gray-600">This section will allow administrators to define and modify class structures, core subjects, and optional subject groups.</p>
               <img src="https://via.placeholder.com/800x400?text=Class+Management+UI" alt="Placeholder for Class Management UI" className="rounded-lg shadow-sm" />
             </div>
          )}
        </div>
      </div>

      <div className="w-full lg:w-96 flex-shrink-0">
        <AIAssistant systemInstruction="You are an admin assistant. Help with user management, system configurations, and general school administration queries."/>
      </div>

      <Modal
        isOpen={isPasswordModalOpen}
        onClose={() => {
          setIsPasswordModalOpen(false);
          setRevealedPasswordId(null);
          setPasswordVerificationError(null);
          setAdminPasswordInput('');
        }}
        title="Verify Admin Password"
        size="sm"
        footer={
          <Button onClick={handleAdminPasswordVerify} loading={loading} variant="primary">
            Verify
          </Button>
        }
      >
        <p className="mb-4 text-gray-700">Please enter your admin password to view user credentials.</p>
        <form onSubmit={handleAdminPasswordVerify} className="space-y-3">
          <div>
            <label htmlFor="admin-password-input" className="sr-only">Admin Password</label>
            <input
              type="password"
              id="admin-password-input"
              value={adminPasswordInput}
              onChange={(e) => setAdminPasswordInput(e.target.value)}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              placeholder="Your Admin Password"
              required
            />
          </div>
          {passwordVerificationError && <p className="text-red-600 text-sm">{passwordVerificationError}</p>}
        </form>
      </Modal>
    </div>
  );
};

export default AdminPage;
