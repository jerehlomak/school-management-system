
import React, { useState, useEffect, useCallback } from 'react';
import { User, UserRole, Payment, PaymentStatus, Course, SchoolClass } from '../types'; // Added Course, SchoolClass
import Table from '../components/Table';
import RemitaPaymentForm from '../components/RemitaPaymentForm';
import { fetchStudentPayments, fetchAllUsers, fetchCourses, fetchClasses } from '../services/apiService'; 
import AIAssistant from '../components/AIAssistant';

interface FeesPageProps {
  user: User;
}

const FeesPage: React.FC<FeesPageProps> = ({ user }) => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]); 
  const [allCourses, setAllCourses] = useState<Course[]>([]);
  const [allClasses, setAllClasses] = useState<SchoolClass[]>([]);

  const loadAllRefData = useCallback(async () => {
    const usersData = await fetchAllUsers(true); 
    setAllUsers(usersData);
    const coursesData = await fetchCourses();
    setAllCourses(coursesData);
    const classesData = await fetchClasses();
    setAllClasses(classesData);
  }, []);

  const loadPayments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      await loadAllRefData(); // Ensure all reference data is loaded first

      let fetchedPayments: Payment[] = [];
      if (user.role === UserRole.Student) {
        fetchedPayments = await fetchStudentPayments(user.id);
      } else if (user.role === UserRole.Parent && user.studentIds && user.studentIds.length > 0) {
        const allStudentPayments = await Promise.all(
          user.studentIds.map(studentId => fetchStudentPayments(studentId))
        );
        fetchedPayments = allStudentPayments.flat();
      } else {
        setError("Payment history not directly available for this role on this page.");
      }
      setPayments(fetchedPayments.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    } catch (err: any) {
      console.error('Error fetching payments:', err);
      setError(err.message || 'Failed to load payment history.');
    } finally {
      setLoading(false);
    }
  }, [user, loadAllRefData]);

  useEffect(() => {
    loadPayments();
  }, [loadPayments]);

  const handlePaymentSuccess = (newPayment: Payment) => {
    setPayments((prev) => [newPayment, ...prev].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };

  const paymentColumns = [
    { header: 'Student Name', accessor: (row: Payment) => allUsers.find(u => u.id === row.studentId)?.name || row.studentId },
    { header: 'Description', accessor: 'description' as keyof Payment },
    { header: 'Amount (₦)', accessor: (row: Payment) => row.amount.toLocaleString() },
    { header: 'Date', accessor: 'date' as keyof Payment },
    { header: 'Status', accessor: (row: Payment) => (
      <span
        className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
          row.status === PaymentStatus.Completed ? 'bg-green-100 text-green-800' :
          row.status === PaymentStatus.Pending ? 'bg-yellow-100 text-yellow-800' :
          'bg-red-100 text-red-800'
        }`}
      >
        {row.status}
      </span>
    )},
    { header: 'RRR', accessor: (row: Payment) => row.rrr || 'N/A' },
    { header: 'Action', accessor: (row: Payment) => (
      row.paymentLink && row.status === PaymentStatus.Pending ? (
        <a
          href={row.paymentLink}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline text-sm"
        >
          Pay Now
        </a>
      ) : '-'
    )},
  ];

  const renderPaymentContent = () => {
    if (loading) {
      return <div className="text-center py-8 text-gray-600">Loading payment history...</div>;
    }

    if (error) {
      return <div className="text-center py-8 text-red-600">{error}</div>;
    }

    const studentForForm = user.role === UserRole.Student 
      ? allUsers.find(s => s.id === user.id) 
      : (user.role === UserRole.Parent && user.studentIds && user.studentIds.length > 0
          ? allUsers.find(s => s.id === user.studentIds?.[0])
          : undefined);

    const payerInfo = studentForForm ? (
      <div className="bg-blue-50 p-4 rounded-md mb-4 border border-blue-200">
        <p className="text-blue-800 text-sm">
          Payment for <span className="font-semibold">{studentForForm.name} (ID: {studentForForm.id})</span>
          {studentForForm.phoneNumber && <span className="ml-2"> | Phone: <span className="font-semibold">{studentForForm.phoneNumber}</span></span>}
        </p>
      </div>
    ) : null;

    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Fees & Payments</h2>

        {studentForForm && (
          <>
            {payerInfo}
            <RemitaPaymentForm
              student={studentForForm}
              onPaymentSuccess={handlePaymentSuccess}
            />
          </>
        )}
        {!studentForForm && user.role === UserRole.Parent && (
          <div className="bg-yellow-50 p-4 rounded-md text-yellow-800">
            <p className="font-semibold">No students linked.</p>
            <p className="text-sm">Please ensure your children are linked to your parent account by an administrator.</p>
          </div>
        )}
        {!studentForForm && user.role === UserRole.Student && (
          <div className="bg-yellow-50 p-4 rounded-md text-yellow-800">
            <p className="font-semibold">Student data not found.</p>
            <p className="text-sm">Could not retrieve your detailed student information.</p>
          </div>
        )}

        <section>
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Payment History</h3>
          <Table
            data={payments}
            columns={paymentColumns}
            rowKey="id"
            emptyMessage="No payment history found."
            caption="Overview of all recorded payments."
          />
        </section>
      </div>
    );
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1">
        {renderPaymentContent()}
      </div>
      <div className="w-full lg:w-96 flex-shrink-0">
        <AIAssistant systemInstruction="You are a financial assistant for school fees. Answer questions about payment policies, due dates, and payment methods."/>
      </div>
    </div>
  );
};

export default FeesPage;