
import React from 'react';
import { User, UserRole } from '../types';
import AIAssistant from '../components/AIAssistant';

interface AdminManageClassesPageProps {
  user: User;
}

const AdminManageClassesPage: React.FC<AdminManageClassesPageProps> = ({ user }) => {
  if (user.role !== UserRole.Admin) {
    return <div className="p-6 text-red-600">Access Denied: Only administrators can access this page.</div>;
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="flex-1">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Manage Classes</h2>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 mb-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Class Configuration</h3>
          <p className="text-gray-700 mb-4">
            This section will allow you to view, add, and edit the structure of your school's classes.
            You'll be able to define core subjects, optional subject groups (e.g., Languages, Vocational),
            and set selection rules (minimum/maximum subjects from a group) for each class.
          </p>

          <div className="bg-blue-50 border border-blue-200 text-blue-800 p-4 rounded-md mb-4">
            <p className="font-semibold">Feature Coming Soon!</p>
            <p className="text-sm">
              The full functionality for managing class structures and subjects is under development.
              Please check back later for updates.
            </p>
          </div>

          <img 
            src="https://via.placeholder.com/800x400?text=Class+Management+UI" 
            alt="Placeholder for Class Management UI" 
            className="rounded-lg shadow-sm w-full max-w-2xl mx-auto" 
          />
        </div>
      </div>

      <div className="w-full lg:w-96 flex-shrink-0">
        <AIAssistant systemInstruction="You are an admin assistant. Help with managing class structures, subjects, and enrollment rules. Provide guidance on best practices for curriculum design."/>
      </div>
    </div>
  );
};

export default AdminManageClassesPage;
